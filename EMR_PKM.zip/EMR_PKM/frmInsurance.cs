﻿using EMR_PKM.DataSet1TableAdapters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EMR_PKM
{
    public partial class frmInsurance : Form
    {
        public frmInsurance()
        {
            InitializeComponent();
        }

        private void codeInsuranceBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.codeInsuranceBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dataSet1);

        }

        private void frmInsurance_Load(object sender, EventArgs e)
        {
            // TODO: 이 코드는 데이터를 'dataSet1.CodeInsuranceSub' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.codeInsuranceSubTableAdapter.Fill(this.dataSet1.CodeInsuranceSub);
            // TODO: 이 코드는 데이터를 'dataSet1.CodeInsurance' 테이블에 로드합니다. 필요 시 이 코드를 이동하거나 제거할 수 있습니다.
            this.codeInsuranceTableAdapter.Fill(this.dataSet1.CodeInsurance);

        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bunifuTileButton1_Click(object sender, EventArgs e)
        {
            //신규 등록
            codeInsuranceBindingSource.AddNew();
        }

        private void bunifuTileButton2_Click(object sender, EventArgs e)
        {
            //자료 추가 및 수정
            codeInsuranceBindingSource.EndEdit();
            codeInsuranceTableAdapter.Update(dataSet1.CodeInsurance);

            MessageBox.Show("자료가 저장 되었습니다.");
        }

        private void bunifuTileButton3_Click(object sender, EventArgs e)
        {
            //현재 선택된 행을 삭제
            codeInsuranceBindingSource.RemoveCurrent();
            codeInsuranceTableAdapter.Update(dataSet1.CodeInsurance);

            MessageBox.Show("자료가 삭제 되었습니다.");
        }

        private void bunifuTileButton6_Click(object sender, EventArgs e)
        {
            //신규 등록
            codeInsuranceSubBindingSource.AddNew();
        }

        private void bunifuTileButton5_Click(object sender, EventArgs e)
        {
            //자료 추가 및 수정
            codeInsuranceSubBindingSource.EndEdit();
            codeInsuranceSubTableAdapter.Update(dataSet1.CodeInsuranceSub);

            MessageBox.Show("자료가 저장 되었습니다.");
        }

        private void bunifuTileButton4_Click(object sender, EventArgs e)
        {
            //현재 선택된 행을 삭제
            codeInsuranceSubBindingSource.RemoveCurrent();
            codeInsuranceSubTableAdapter.Update(dataSet1.CodeInsuranceSub);

            MessageBox.Show("자료가 삭제 되었습니다.");
        }
    }
}
