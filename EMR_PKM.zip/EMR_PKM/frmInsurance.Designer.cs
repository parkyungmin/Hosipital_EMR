﻿namespace EMR_PKM
{
    partial class frmInsurance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label insuCodeLabel;
            System.Windows.Forms.Label insuNameLabel;
            System.Windows.Forms.Label myRateLabel;
            System.Windows.Forms.Label subCodeLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInsurance));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.codeInsuranceSubDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codeInsuranceSubBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.codeInsuranceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new EMR_PKM.DataSet1();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.codeInsuranceDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.codeInsuranceTableAdapter = new EMR_PKM.DataSet1TableAdapters.CodeInsuranceTableAdapter();
            this.tableAdapterManager = new EMR_PKM.DataSet1TableAdapters.TableAdapterManager();
            this.codeInsuranceSubTableAdapter = new EMR_PKM.DataSet1TableAdapters.CodeInsuranceSubTableAdapter();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.insuCodeTextBox = new System.Windows.Forms.TextBox();
            this.insuNameTextBox = new System.Windows.Forms.TextBox();
            this.myRateTextBox = new System.Windows.Forms.TextBox();
            this.subCodeTextBox = new System.Windows.Forms.TextBox();
            this.bunifuTileButton3 = new Bunifu.Framework.UI.BunifuTileButton();
            this.bunifuTileButton2 = new Bunifu.Framework.UI.BunifuTileButton();
            this.bunifuTileButton1 = new Bunifu.Framework.UI.BunifuTileButton();
            this.bunifuTileButton4 = new Bunifu.Framework.UI.BunifuTileButton();
            this.bunifuTileButton5 = new Bunifu.Framework.UI.BunifuTileButton();
            this.bunifuTileButton6 = new Bunifu.Framework.UI.BunifuTileButton();
            insuCodeLabel = new System.Windows.Forms.Label();
            insuNameLabel = new System.Windows.Forms.Label();
            myRateLabel = new System.Windows.Forms.Label();
            subCodeLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.codeInsuranceSubDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.codeInsuranceSubBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.codeInsuranceBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.codeInsuranceDataGridView)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // insuCodeLabel
            // 
            insuCodeLabel.AutoSize = true;
            insuCodeLabel.Location = new System.Drawing.Point(422, 172);
            insuCodeLabel.Name = "insuCodeLabel";
            insuCodeLabel.Size = new System.Drawing.Size(67, 12);
            insuCodeLabel.TabIndex = 23;
            insuCodeLabel.Text = "Insu Code:";
            // 
            // insuNameLabel
            // 
            insuNameLabel.AutoSize = true;
            insuNameLabel.Location = new System.Drawing.Point(418, 214);
            insuNameLabel.Name = "insuNameLabel";
            insuNameLabel.Size = new System.Drawing.Size(71, 12);
            insuNameLabel.TabIndex = 24;
            insuNameLabel.Text = "Insu Name:";
            // 
            // myRateLabel
            // 
            myRateLabel.AutoSize = true;
            myRateLabel.Location = new System.Drawing.Point(433, 257);
            myRateLabel.Name = "myRateLabel";
            myRateLabel.Size = new System.Drawing.Size(56, 12);
            myRateLabel.TabIndex = 25;
            myRateLabel.Text = "My Rate:";
            // 
            // subCodeLabel
            // 
            subCodeLabel.AutoSize = true;
            subCodeLabel.Location = new System.Drawing.Point(424, 429);
            subCodeLabel.Name = "subCodeLabel";
            subCodeLabel.Size = new System.Drawing.Size(65, 12);
            subCodeLabel.TabIndex = 26;
            subCodeLabel.Text = "Sub Code:";
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 30;
            this.bunifuElipse1.TargetControl = this;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel1.Controls.Add(this.bunifuImageButton1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1200, 62);
            this.panel1.TabIndex = 2;
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuImageButton1.Dock = System.Windows.Forms.DockStyle.Right;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(1152, 0);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(48, 62);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.bunifuImageButton1.TabIndex = 2;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            this.bunifuImageButton1.Click += new System.EventHandler(this.bunifuImageButton1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("휴먼둥근헤드라인", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(238, 41);
            this.label1.TabIndex = 0;
            this.label1.Text = "진료의 관리";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.codeInsuranceSubDataGridView);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.codeInsuranceDataGridView);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 62);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(343, 638);
            this.panel2.TabIndex = 3;
            // 
            // codeInsuranceSubDataGridView
            // 
            this.codeInsuranceSubDataGridView.AutoGenerateColumns = false;
            this.codeInsuranceSubDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.codeInsuranceSubDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.codeInsuranceSubDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.codeInsuranceSubDataGridView.DataSource = this.codeInsuranceSubBindingSource;
            this.codeInsuranceSubDataGridView.Dock = System.Windows.Forms.DockStyle.Top;
            this.codeInsuranceSubDataGridView.Location = new System.Drawing.Point(0, 318);
            this.codeInsuranceSubDataGridView.Name = "codeInsuranceSubDataGridView";
            this.codeInsuranceSubDataGridView.RowTemplate.Height = 23;
            this.codeInsuranceSubDataGridView.Size = new System.Drawing.Size(343, 220);
            this.codeInsuranceSubDataGridView.TabIndex = 3;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "InsuCode";
            this.dataGridViewTextBoxColumn4.HeaderText = "InsuCode";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Visible = false;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "SubCode";
            this.dataGridViewTextBoxColumn5.HeaderText = "보조코드";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 300;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "MyRate";
            this.dataGridViewTextBoxColumn6.HeaderText = "MyRate";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Visible = false;
            // 
            // codeInsuranceSubBindingSource
            // 
            this.codeInsuranceSubBindingSource.DataMember = "FK_CodeInsuranceSub_CodeInsurance";
            this.codeInsuranceSubBindingSource.DataSource = this.codeInsuranceBindingSource;
            // 
            // codeInsuranceBindingSource
            // 
            this.codeInsuranceBindingSource.DataMember = "CodeInsurance";
            this.codeInsuranceBindingSource.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Gainsboro;
            this.panel4.Controls.Add(this.label3);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 269);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(343, 49);
            this.panel4.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("휴먼둥근헤드라인", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(87, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(147, 22);
            this.label3.TabIndex = 0;
            this.label3.Text = "진료과 리스트";
            // 
            // codeInsuranceDataGridView
            // 
            this.codeInsuranceDataGridView.AutoGenerateColumns = false;
            this.codeInsuranceDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.codeInsuranceDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.codeInsuranceDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.codeInsuranceDataGridView.DataSource = this.codeInsuranceBindingSource;
            this.codeInsuranceDataGridView.Dock = System.Windows.Forms.DockStyle.Top;
            this.codeInsuranceDataGridView.Location = new System.Drawing.Point(0, 49);
            this.codeInsuranceDataGridView.Name = "codeInsuranceDataGridView";
            this.codeInsuranceDataGridView.RowTemplate.Height = 23;
            this.codeInsuranceDataGridView.Size = new System.Drawing.Size(343, 220);
            this.codeInsuranceDataGridView.TabIndex = 4;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "InsuCode";
            this.dataGridViewTextBoxColumn1.HeaderText = "보험코드";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 80;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "InsuName";
            this.dataGridViewTextBoxColumn2.HeaderText = "보험명";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 120;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "MyRate";
            this.dataGridViewTextBoxColumn3.HeaderText = "비율";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gainsboro;
            this.panel3.Controls.Add(this.label2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(343, 49);
            this.panel3.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("휴먼둥근헤드라인", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(87, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 22);
            this.label2.TabIndex = 0;
            this.label2.Text = "진료과 리스트";
            // 
            // codeInsuranceTableAdapter
            // 
            this.codeInsuranceTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CodeDeptTableAdapter = null;
            this.tableAdapterManager.CodeDoctorSignTableAdapter = null;
            this.tableAdapterManager.CodeDoctorTableAdapter = null;
            this.tableAdapterManager.CodeInsuranceSubTableAdapter = this.codeInsuranceSubTableAdapter;
            this.tableAdapterManager.CodeInsuranceTableAdapter = this.codeInsuranceTableAdapter;
            this.tableAdapterManager.EmployeeTableAdapter = null;
            this.tableAdapterManager.PatientTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = EMR_PKM.DataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // codeInsuranceSubTableAdapter
            // 
            this.codeInsuranceSubTableAdapter.ClearBeforeFill = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("한컴 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(408, 121);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 27);
            this.label5.TabIndex = 22;
            this.label5.Text = "보험유형";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("한컴 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(408, 380);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 27);
            this.label4.TabIndex = 23;
            this.label4.Text = "보험유형 보조";
            // 
            // insuCodeTextBox
            // 
            this.insuCodeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.codeInsuranceBindingSource, "InsuCode", true));
            this.insuCodeTextBox.Location = new System.Drawing.Point(495, 169);
            this.insuCodeTextBox.Name = "insuCodeTextBox";
            this.insuCodeTextBox.Size = new System.Drawing.Size(100, 21);
            this.insuCodeTextBox.TabIndex = 24;
            // 
            // insuNameTextBox
            // 
            this.insuNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.codeInsuranceBindingSource, "InsuName", true));
            this.insuNameTextBox.Location = new System.Drawing.Point(495, 211);
            this.insuNameTextBox.Name = "insuNameTextBox";
            this.insuNameTextBox.Size = new System.Drawing.Size(100, 21);
            this.insuNameTextBox.TabIndex = 25;
            // 
            // myRateTextBox
            // 
            this.myRateTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.codeInsuranceBindingSource, "MyRate", true));
            this.myRateTextBox.Location = new System.Drawing.Point(495, 254);
            this.myRateTextBox.Name = "myRateTextBox";
            this.myRateTextBox.Size = new System.Drawing.Size(100, 21);
            this.myRateTextBox.TabIndex = 26;
            // 
            // subCodeTextBox
            // 
            this.subCodeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.codeInsuranceSubBindingSource, "SubCode", true));
            this.subCodeTextBox.Location = new System.Drawing.Point(495, 426);
            this.subCodeTextBox.Name = "subCodeTextBox";
            this.subCodeTextBox.Size = new System.Drawing.Size(100, 21);
            this.subCodeTextBox.TabIndex = 27;
            // 
            // bunifuTileButton3
            // 
            this.bunifuTileButton3.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton3.color = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton3.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.bunifuTileButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTileButton3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuTileButton3.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton3.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton3.Image")));
            this.bunifuTileButton3.ImagePosition = 30;
            this.bunifuTileButton3.ImageZoom = 40;
            this.bunifuTileButton3.LabelPosition = 43;
            this.bunifuTileButton3.LabelText = "삭제";
            this.bunifuTileButton3.Location = new System.Drawing.Point(962, 169);
            this.bunifuTileButton3.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.bunifuTileButton3.Name = "bunifuTileButton3";
            this.bunifuTileButton3.Size = new System.Drawing.Size(127, 135);
            this.bunifuTileButton3.TabIndex = 30;
            this.bunifuTileButton3.Click += new System.EventHandler(this.bunifuTileButton3_Click);
            // 
            // bunifuTileButton2
            // 
            this.bunifuTileButton2.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton2.color = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton2.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.bunifuTileButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTileButton2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuTileButton2.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton2.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton2.Image")));
            this.bunifuTileButton2.ImagePosition = 30;
            this.bunifuTileButton2.ImageZoom = 40;
            this.bunifuTileButton2.LabelPosition = 43;
            this.bunifuTileButton2.LabelText = "저장";
            this.bunifuTileButton2.Location = new System.Drawing.Point(830, 169);
            this.bunifuTileButton2.Margin = new System.Windows.Forms.Padding(8, 10, 8, 10);
            this.bunifuTileButton2.Name = "bunifuTileButton2";
            this.bunifuTileButton2.Size = new System.Drawing.Size(127, 135);
            this.bunifuTileButton2.TabIndex = 29;
            this.bunifuTileButton2.Click += new System.EventHandler(this.bunifuTileButton2_Click);
            // 
            // bunifuTileButton1
            // 
            this.bunifuTileButton1.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton1.color = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton1.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.bunifuTileButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTileButton1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuTileButton1.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton1.Image")));
            this.bunifuTileButton1.ImagePosition = 30;
            this.bunifuTileButton1.ImageZoom = 40;
            this.bunifuTileButton1.LabelPosition = 43;
            this.bunifuTileButton1.LabelText = "신규등록";
            this.bunifuTileButton1.Location = new System.Drawing.Point(696, 169);
            this.bunifuTileButton1.Margin = new System.Windows.Forms.Padding(8, 10, 8, 10);
            this.bunifuTileButton1.Name = "bunifuTileButton1";
            this.bunifuTileButton1.Size = new System.Drawing.Size(127, 135);
            this.bunifuTileButton1.TabIndex = 28;
            this.bunifuTileButton1.Click += new System.EventHandler(this.bunifuTileButton1_Click);
            // 
            // bunifuTileButton4
            // 
            this.bunifuTileButton4.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton4.color = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton4.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.bunifuTileButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTileButton4.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuTileButton4.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton4.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton4.Image")));
            this.bunifuTileButton4.ImagePosition = 30;
            this.bunifuTileButton4.ImageZoom = 40;
            this.bunifuTileButton4.LabelPosition = 43;
            this.bunifuTileButton4.LabelText = "삭제";
            this.bunifuTileButton4.Location = new System.Drawing.Point(962, 426);
            this.bunifuTileButton4.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.bunifuTileButton4.Name = "bunifuTileButton4";
            this.bunifuTileButton4.Size = new System.Drawing.Size(127, 135);
            this.bunifuTileButton4.TabIndex = 33;
            this.bunifuTileButton4.Click += new System.EventHandler(this.bunifuTileButton4_Click);
            // 
            // bunifuTileButton5
            // 
            this.bunifuTileButton5.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton5.color = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton5.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.bunifuTileButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTileButton5.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuTileButton5.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton5.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton5.Image")));
            this.bunifuTileButton5.ImagePosition = 30;
            this.bunifuTileButton5.ImageZoom = 40;
            this.bunifuTileButton5.LabelPosition = 43;
            this.bunifuTileButton5.LabelText = "저장";
            this.bunifuTileButton5.Location = new System.Drawing.Point(830, 426);
            this.bunifuTileButton5.Margin = new System.Windows.Forms.Padding(8, 10, 8, 10);
            this.bunifuTileButton5.Name = "bunifuTileButton5";
            this.bunifuTileButton5.Size = new System.Drawing.Size(127, 135);
            this.bunifuTileButton5.TabIndex = 32;
            this.bunifuTileButton5.Click += new System.EventHandler(this.bunifuTileButton5_Click);
            // 
            // bunifuTileButton6
            // 
            this.bunifuTileButton6.BackColor = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton6.color = System.Drawing.Color.SeaGreen;
            this.bunifuTileButton6.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.bunifuTileButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTileButton6.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuTileButton6.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton6.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton6.Image")));
            this.bunifuTileButton6.ImagePosition = 30;
            this.bunifuTileButton6.ImageZoom = 40;
            this.bunifuTileButton6.LabelPosition = 43;
            this.bunifuTileButton6.LabelText = "신규등록";
            this.bunifuTileButton6.Location = new System.Drawing.Point(696, 426);
            this.bunifuTileButton6.Margin = new System.Windows.Forms.Padding(8, 10, 8, 10);
            this.bunifuTileButton6.Name = "bunifuTileButton6";
            this.bunifuTileButton6.Size = new System.Drawing.Size(127, 135);
            this.bunifuTileButton6.TabIndex = 31;
            this.bunifuTileButton6.Click += new System.EventHandler(this.bunifuTileButton6_Click);
            // 
            // frmInsurance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 700);
            this.Controls.Add(this.bunifuTileButton4);
            this.Controls.Add(this.bunifuTileButton5);
            this.Controls.Add(this.bunifuTileButton6);
            this.Controls.Add(this.bunifuTileButton3);
            this.Controls.Add(this.bunifuTileButton2);
            this.Controls.Add(this.bunifuTileButton1);
            this.Controls.Add(subCodeLabel);
            this.Controls.Add(this.subCodeTextBox);
            this.Controls.Add(myRateLabel);
            this.Controls.Add(this.myRateTextBox);
            this.Controls.Add(insuNameLabel);
            this.Controls.Add(this.insuNameTextBox);
            this.Controls.Add(insuCodeLabel);
            this.Controls.Add(this.insuCodeTextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmInsurance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmInsurance";
            this.Load += new System.EventHandler(this.frmInsurance_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.codeInsuranceSubDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.codeInsuranceSubBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.codeInsuranceBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.codeInsuranceDataGridView)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.BindingSource codeInsuranceBindingSource;
        private DataSet1 dataSet1;
        private DataSet1TableAdapters.CodeInsuranceTableAdapter codeInsuranceTableAdapter;
        private DataSet1TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView codeInsuranceDataGridView;
        private DataSet1TableAdapters.CodeInsuranceSubTableAdapter codeInsuranceSubTableAdapter;
        private System.Windows.Forms.BindingSource codeInsuranceSubBindingSource;
        private System.Windows.Forms.DataGridView codeInsuranceSubDataGridView;
        private System.Windows.Forms.TextBox subCodeTextBox;
        private System.Windows.Forms.TextBox myRateTextBox;
        private System.Windows.Forms.TextBox insuNameTextBox;
        private System.Windows.Forms.TextBox insuCodeTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton4;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton5;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton6;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton3;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton2;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton1;
    }
}